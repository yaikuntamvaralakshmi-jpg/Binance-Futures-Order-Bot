# Binance Futures Order Bot (Assignment Scaffold)\n\nSee src/ for code.
Adapters included:
- src/utils/binance_adapter_python.py (python-binance)
- src/utils/binance_adapter_connector.py (binance-connector)

CI: .github/workflows/ci.yml runs pytest.

Run tests locally:
pip install pytest reportlab
pytest -q
