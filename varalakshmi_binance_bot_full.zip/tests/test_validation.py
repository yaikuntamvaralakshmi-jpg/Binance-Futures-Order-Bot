import pytest
from src.utils.validation import validate_symbol, validate_quantity, validate_price

def test_validate_symbol_valid():
    assert validate_symbol('BTCUSDT') == 'BTCUSDT'
    assert validate_symbol('ethusdt') == 'ETHUSDT'

def test_validate_symbol_invalid():
    with pytest.raises(ValueError):
        validate_symbol('INVALID')

def test_validate_quantity_valid():
    assert validate_quantity(0.1) == 0.1
    assert validate_quantity('2') == 2.0

def test_validate_quantity_invalid():
    with pytest.raises(ValueError):
        validate_quantity(0)
    with pytest.raises(ValueError):
        validate_quantity('abc')

def test_validate_price_valid():
    assert validate_price(100) == 100.0
    assert validate_price('250.5') == 250.5

def test_validate_price_invalid():
    with pytest.raises(ValueError):
        validate_price(0)
    with pytest.raises(ValueError):
        validate_price('xyz')
