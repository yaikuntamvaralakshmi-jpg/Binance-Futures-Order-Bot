# CLI entrypoint
import argparse
from src.logger_setup import get_logger
from src.market_orders import place_market_order
from src.limit_orders import place_limit_order

logger = get_logger()

def main():
    parser = argparse.ArgumentParser(description='Binance Futures Order Bot CLI')
    sub = parser.add_subparsers(dest='command', required=True)

    mkt = sub.add_parser('market', help='Place a market order')
    mkt.add_argument('symbol', type=str)
    mkt.add_argument('side', choices=['BUY','SELL'])
    mkt.add_argument('quantity', type=float)

    lim = sub.add_parser('limit', help='Place a limit order')
    lim.add_argument('symbol', type=str)
    lim.add_argument('side', choices=['BUY','SELL'])
    lim.add_argument('quantity', type=float)
    lim.add_argument('price', type=float)

    args = parser.parse_args()
    if args.command == 'market':
        place_market_order(args.symbol, args.side, args.quantity)
    elif args.command == 'limit':
        place_limit_order(args.symbol, args.side, args.quantity, args.price)

if __name__ == '__main__':
    main()
