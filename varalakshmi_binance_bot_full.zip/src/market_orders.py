from src.utils.validation import validate_symbol, validate_quantity
from src.utils.binance_client import client
from src.logger_setup import get_logger
logger = get_logger(__name__)
def place_market_order(symbol, side, quantity):
    symbol = validate_symbol(symbol)
    quantity = validate_quantity(quantity)
    logger.info(f'Placing market order: {side} {quantity} {symbol}')
    resp = client.market_order(symbol, side, quantity)
    logger.debug(f'Order response: {resp}')
    print('ORDER_RESPONSE:', resp)
    return resp
