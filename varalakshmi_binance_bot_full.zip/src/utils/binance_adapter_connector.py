"""Adapter for official binance-connector.
Uses UMFutures (for USDT-M futures) when LIVE_MODE is True; otherwise acts as mock.
"""
import os
from src.logger_setup import get_logger
from src.config import LIVE_MODE, BINANCE_API_KEY, BINANCE_API_SECRET
logger = get_logger(__name__)

class ConnectorAdapter:
    def __init__(self, api_key=None, api_secret=None, testnet=False):
        self.api_key = api_key or BINANCE_API_KEY
        self.api_secret = api_secret or BINANCE_API_SECRET
        self.testnet = testnet
        self.client = None
        if LIVE_MODE:
            try:
                from binance.um_futures import UMFutures
                self.client = UMFutures(key=self.api_key, secret=self.api_secret)
                logger.info('binance-connector UMFutures client initialized')
            except Exception as e:
                logger.exception('Failed to import/init binance-connector: %s', e)
                raise

    def market_order(self, symbol, side, quantity):
        if not LIVE_MODE or self.client is None:
            logger.info('[connector MOCK] market_order %s %s %s', side, quantity, symbol)
            return {'status':'TEST','type':'MARKET','symbol':symbol,'side':side,'qty':quantity}
        try:
            resp = self.client.new_order(symbol=symbol, side=side, type='MARKET', quantity=quantity)
            logger.debug('connector resp: %s', resp)
            return resp
        except Exception as e:
            logger.exception('Market order failed: %s', e)
            raise

    def limit_order(self, symbol, side, quantity, price):
        if not LIVE_MODE or self.client is None:
            logger.info('[connector MOCK] limit_order %s %s %s @ %s', side, quantity, symbol, price)
            return {'status':'TEST','type':'LIMIT','symbol':symbol,'side':side,'qty':quantity,'price':price}
        try:
            resp = self.client.new_order(symbol=symbol, side=side, type='LIMIT', timeInForce='GTC', price=price, quantity=quantity)
            logger.debug('connector resp: %s', resp)
            return resp
        except Exception as e:
            logger.exception('Limit order failed: %s', e)
            raise

def get_adapter(testnet=False):
    return ConnectorAdapter(testnet=testnet)
