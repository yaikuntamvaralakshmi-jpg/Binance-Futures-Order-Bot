VALID_SYMBOLS = set(['BTCUSDT','ETHUSDT','BNBUSDT','XRPUSDT'])
def validate_symbol(symbol):
    if not isinstance(symbol, str):
        raise ValueError('Symbol must be string')
    s = symbol.upper()
    if s not in VALID_SYMBOLS:
        raise ValueError(f'Unsupported symbol: {s}')
    return s
def validate_quantity(q):
    try:
        qf = float(q)
    except:
        raise ValueError('Quantity must be a number')
    if qf <= 0:
        raise ValueError('Quantity must be > 0')
    return qf
def validate_price(p):
    try:
        pf = float(p)
    except:
        raise ValueError('Price must be a number')
    if pf <= 0:
        raise ValueError('Price must be > 0')
    return pf
