"""Adapter for python-binance (unofficial).
Provides a safe wrapper with market_order and limit_order that map to futures_create_order.
The adapter will only attempt to import python-binance when LIVE_MODE is True.
"""
import os
from src.logger_setup import get_logger
from src.config import LIVE_MODE, BINANCE_API_KEY, BINANCE_API_SECRET
logger = get_logger(__name__)

class PythonBinanceAdapter:
    def __init__(self, api_key=None, api_secret=None, testnet=False):
        self.api_key = api_key or BINANCE_API_KEY
        self.api_secret = api_secret or BINANCE_API_SECRET
        self.testnet = testnet
        self.client = None
        if LIVE_MODE:
            try:
                from binance.client import Client
                self.client = Client(self.api_key, self.api_secret)
                logger.info('python-binance client initialized')
            except Exception as e:
                logger.exception('Failed to import/init python-binance client: %s', e)
                raise

    def market_order(self, symbol, side, quantity):
        if not LIVE_MODE or self.client is None:
            logger.info('[python-binance MOCK] market_order %s %s %s', side, quantity, symbol)
            return {'status':'TEST','type':'MARKET','symbol':symbol,'side':side,'qty':quantity}
        try:
            resp = self.client.futures_create_order(symbol=symbol, side=side, type='MARKET', quantity=quantity)
            logger.debug('python-binance resp: %s', resp)
            return resp
        except Exception as e:
            logger.exception('Market order failed: %s', e)
            raise

    def limit_order(self, symbol, side, quantity, price):
        if not LIVE_MODE or self.client is None:
            logger.info('[python-binance MOCK] limit_order %s %s %s @ %s', side, quantity, symbol, price)
            return {'status':'TEST','type':'LIMIT','symbol':symbol,'side':side,'qty':quantity,'price':price}
        try:
            resp = self.client.futures_create_order(symbol=symbol, side=side, type='LIMIT', timeInForce='GTC', price=price, quantity=quantity)
            logger.debug('python-binance resp: %s', resp)
            return resp
        except Exception as e:
            logger.exception('Limit order failed: %s', e)
            raise

def get_adapter(testnet=False):
    return PythonBinanceAdapter(testnet=testnet)
