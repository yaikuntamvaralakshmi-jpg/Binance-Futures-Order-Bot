from src.config import BINANCE_API_KEY, BINANCE_API_SECRET, LIVE_MODE
from src.logger_setup import get_logger
logger = get_logger(__name__)
class BinanceClientMock:
    def __init__(self):
        self.live = False
    def market_order(self, symbol, side, quantity):
        logger.info(f'[MOCK] market_order {side} {quantity} {symbol}')
        return {'status':'TEST','type':'MARKET','symbol':symbol,'side':side,'qty':quantity}
    def limit_order(self, symbol, side, quantity, price):
        logger.info(f'[MOCK] limit_order {side} {quantity} {symbol} @ {price}')
        return {'status':'TEST','type':'LIMIT','symbol':symbol,'side':side,'qty':quantity,'price':price}
client = BinanceClientMock()
