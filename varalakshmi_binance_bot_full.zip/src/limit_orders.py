from src.utils.validation import validate_symbol, validate_quantity, validate_price
from src.utils.binance_client import client
from src.logger_setup import get_logger
logger = get_logger(__name__)
def place_limit_order(symbol, side, quantity, price):
    symbol = validate_symbol(symbol)
    quantity = validate_quantity(quantity)
    price = validate_price(price)
    logger.info(f'Placing limit order: {side} {quantity} {symbol} @ {price}')
    resp = client.limit_order(symbol, side, quantity, price)
    logger.debug(f'Order response: {resp}')
    print('ORDER_RESPONSE:', resp)
    return resp
